package test5;

public class BitBucketTest {

	public static void main(String args[])
	{
		String myOpinion1="NO";
		String myOpinion2="Not Sure";
		
		System.out.println("Will Bit Bucket Rock??..."+myOpinion1 +"Recheck" + "Ok!");
		System.out.println("Test pull request");
	}
}
