
public class TestPull {
public void method(){
	System.out.println("New file added for pull");
}
}
